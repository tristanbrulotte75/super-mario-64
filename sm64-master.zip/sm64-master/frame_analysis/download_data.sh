wget https://googledrive.com/host/0B_WJBlETj-zLSDE2cjFqUHk3QlU/stars.tar.gz
mkdir data
tar -zxf stars.tar.gz -C data
